"""Chạy trọn luồng `pull` và `parse-xml` với server giả lập."""

from pathlib import Path
from unittest import mock

import requests
from openpyxl import load_workbook

from hddt import cli
from tests.test_client import FakeGdt

FIX = Path(__file__).parent / "fixtures" / "hoadon_mau.xml"
RealSession = requests.Session


def _run(argv, fake, monkeypatch):
    session = mock.Mock(spec=RealSession)
    session.request.side_effect = fake.request
    session.proxies = {}
    monkeypatch.setattr(requests, "Session", lambda: session)
    monkeypatch.setenv("GDT_USERNAME", "0109876543")
    monkeypatch.setenv("GDT_PASSWORD", "secret")
    monkeypatch.setenv("REQUEST_DELAY_MS", "0")
    monkeypatch.setenv("PAGE_SIZE", "2")
    return cli.main(argv)


def test_pull_end_to_end(tmp_path, monkeypatch):
    fake = FakeGdt()
    out = tmp_path / "out"
    code = _run(["--env", str(tmp_path / "no.env"), "pull", "--thang", "12/2025", "--chieu", "mua", "--thu-muc", str(out), "--luong", "2"], fake, monkeypatch)
    assert code == 2  # có 1 hóa đơn không tải được XML (HTTP 500) -> mã thoát 2
    xlsx = out / "HoaDon_20251201_20251231.xlsx"
    assert xlsx.is_file()
    wb = load_workbook(xlsx)
    ws = wb["HoaDon"]
    rows = list(ws.iter_rows(values_only=True))
    assert rows[0][:5] == ("Chiều", "Nguồn", "Ký hiệu mẫu số", "Ký hiệu hóa đơn", "Số hóa đơn")
    assert len(rows) == 5  # 1 header + 4 hóa đơn
    by_no = {int(r[4]): r for r in rows[1:]}
    assert by_no[125][18] == "Hóa đơn mới" and by_no[125][19] == "Đã cấp mã hóa đơn"
    assert by_no[9][1] == "Máy tính tiền"
    assert "HTTP 500" in by_no[126][-1]
    assert (out / "xml" / "purchase" / "purchase_query_0312345678_1_C25TAA_125.xml").is_file()
    assert (out / "xml" / "purchase" / "purchase_query_0312345678_1_C25TAA_125.html").is_file()
    err_rows = list(wb["Loi"].iter_rows(values_only=True))
    assert len(err_rows) == 2 and err_rows[1][5] == "126"
    assert (out / "danh_sach_20251201_20251231.json").is_file()


def test_pull_reuses_existing_xml(tmp_path, monkeypatch):
    fake = FakeGdt()
    out = tmp_path / "out"
    _run(["--env", "x", "pull", "--thang", "12/2025", "--chieu", "mua", "--thu-muc", str(out), "--khong-mtt"], fake, monkeypatch)
    first = sum(1 for c in fake.calls if "export-xml" in c[1])
    _run(["--env", "x", "pull", "--thang", "12/2025", "--chieu", "mua", "--thu-muc", str(out), "--khong-mtt"], fake, monkeypatch)
    second = sum(1 for c in fake.calls if "export-xml" in c[1]) - first
    assert first == 3 and second == 1  # lần 2 chỉ tải lại hóa đơn 126 bị lỗi


def test_parse_xml_offline(tmp_path, monkeypatch):
    folder = tmp_path / "xml" / "purchase"
    folder.mkdir(parents=True)
    (folder / "a.xml").write_bytes(FIX.read_bytes())
    out = tmp_path / "local.xlsx"
    code = cli.main(["--env", "x", "parse-xml", str(tmp_path / "xml"), "--excel", str(out)])
    assert code == 0
    wb = load_workbook(out)
    assert wb["HoaDon"].max_row == 2
    assert wb["ChiTiet"].max_row == 4
    detail = list(wb["ChiTiet"].iter_rows(min_row=2, values_only=True))
    assert detail[0][12] == "Dịch vụ tư vấn" and detail[0][20] == 200000


def test_global_options_accepted_after_subcommand(tmp_path, monkeypatch):
    fake = FakeGdt()
    out = tmp_path / "out"
    log = tmp_path / "log.txt"
    code = _run(["pull", "--env", "x", "--log-file", str(log), "--thang", "01/12/2025-31/12/2025", "--chieu", "mua", "--thu-muc", str(out), "--khong-xml"], fake, monkeypatch)
    assert code == 0
    assert (out / "HoaDon_20251201_20251231.xlsx").is_file()
    assert log.is_file()


def test_gui_helpers_without_tk(tmp_path):
    import keo_hoa_don as gui

    env = tmp_path / ".env"
    (tmp_path / ".env.example").write_text("# mau\nGDT_USERNAME=\nGDT_PASSWORD=\nOUTPUT_DIR=output\n", encoding="utf-8")
    gui.save_env({"GDT_USERNAME": "0109876543", "GDT_PASSWORD": "a=b", "XML_WORKERS": "2"}, env)
    vals = gui.read_env(env)
    assert vals["GDT_USERNAME"] == "0109876543" and vals["GDT_PASSWORD"] == "a=b" and vals["XML_WORKERS"] == "2"
    assert env.read_text(encoding="utf-8").startswith("# mau\n")

    opts = gui.build_options({"username": "0109876543", "password": "x", "start": "01/01/2024", "end": "31/12/2024", "direction": "purchase", "include_sco": False})
    assert opts.families == ["query"] and opts.directions == ["purchase"]
    assert str(opts.start) == "2024-01-01" and str(opts.end) == "2024-12-31"
    import pytest

    with pytest.raises(ValueError):
        gui.build_options({"username": "", "password": "x", "start": "01/01/2024", "end": "31/12/2024"})
    with pytest.raises(ValueError):
        gui.build_options({"username": "a", "password": "x", "start": "31/12/2024", "end": "01/01/2024"})
